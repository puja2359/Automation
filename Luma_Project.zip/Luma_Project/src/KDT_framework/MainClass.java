package KDT_framework;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class MainClass 
{
public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.edge.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\msedgedriver.exe");
        WebDriver driver= new EdgeDriver();
        Thread.sleep(2000);
        ReadExcelClass r= new ReadExcelClass();
        
	}

}
